javac -cp sqlite-jdbc-3.23.1.jar: Main.java
java -cp sqlite-jdbc-3.23.1.jar: Main